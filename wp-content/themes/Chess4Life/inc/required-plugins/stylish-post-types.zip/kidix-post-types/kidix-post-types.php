<?php

/*
 * Plugin Name: Kidix Custom Post Types
 * Plugin URI: http://stylishthemes.co/
 * Description: Custom Post Types for Kidix WordPress Theme
 * Author: Stylish Themes
 * Version: 1.0
 * Author URI: http://stylishthemes.co/
 * License: GPL v2
**/

add_action( 'init', 'stylish_register_post_types', 0 );

function stylish_register_post_types() {
	register_post_type( 'teacher',
		array(
			'label' => __( 'Teacher', 'stylish' ),
			'labels' => array(
				'name' => __( 'Teachers', 'stylish' ),
				'singular_name' => __( 'Teacher', 'stylish' ),
				'all_items' => __( 'All Teachers', 'stylish' ),
			),
			'public' => true,
			'has_archive' => true,
			'menu_position' => 5,
			'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
			'rewrite' => array(
				'slug' => 'teacher',
				'with_front' => false
			),
		)
	);
	
	register_post_type( 'album',
		array(
			'label' => __( 'Album', 'stylish' ),
			'labels' => array(
				'name' => __( 'Albums', 'stylish' ),
				'singular_name' => __( 'Album', 'stylish' ),
				'all_items' => __( 'All Albums', 'stylish' ),
			),
			'public' => true,
			'has_archive' => true,
			'menu_position' => 5,
			'supports' => array( 'title', 'editor', 'thumbnail' ),
			'rewrite' => array(
				'slug' => 'album',
				'with_front' => false
			),
		)
	);
	
	register_post_type( 'class',
		array(
			'label' => __( 'Class', 'stylish' ),
			'labels' => array(
				'name' => __( 'Classes', 'stylish' ),
				'singular_name' => __( 'Class', 'stylish' ),
				'all_items' => __( 'All Classes', 'stylish' ),
			),
			'public' => true,
			'has_archive' => true,
			'menu_position' => 5,
			'supports' => array( 'title', 'editor', 'thumbnail', 'comments' ),
			'rewrite' => array(
				'slug' => 'class',
				'with_front' => false
			),
		)
	);
}


add_action( 'init', 'stylish_register_taxonomies', 0 );

function stylish_register_taxonomies() {
	register_taxonomy( 'teacher-type', 'teacher', array(
		'label'             => 'Teacher Type',
		'labels'            => array(
			'name'              => __( 'Teacher Types', 'stylish' ),
			'singular_name'     => __( 'Teacher Type', 'stylish' ),
			'search_items'      => __( 'Search Teacher Types', 'stylish' ),
			'all_items'         => __( 'All Teacher Types', 'stylish' ),
			'edit_item'         => __( 'Edit Teacher Type', 'stylish' ),
			'update_item'       => __( 'Update Teacher Type', 'stylish' ),
			'add_new_item'      => __( 'Add New Teacher Type', 'stylish' ),
			'new_item_name'     => __( 'New Teacher Type Name', 'stylish' ),
			'menu_name'         => __( 'Teacher Types', 'stylish' ),
		),
		'hierarchical'      => true,
		'show_ui'           => true,
	) );
	
	register_taxonomy( 'class-type', 'class', array(
		'label'             => 'Class Type',
		'labels'            => array(
			'name'              => __( 'Class Types', 'stylish' ),
			'singular_name'     => __( 'Class Type', 'stylish' ),
			'search_items'      => __( 'Search Class Types', 'stylish' ),
			'all_items'         => __( 'All Class Types', 'stylish' ),
			'edit_item'         => __( 'Edit Class Type', 'stylish' ),
			'update_item'       => __( 'Update Class Type', 'stylish' ),
			'add_new_item'      => __( 'Add New Class Type', 'stylish' ),
			'new_item_name'     => __( 'New Class Type Name', 'stylish' ),
			'menu_name'         => __( 'Class Types', 'stylish' ),
		),
		'hierarchical'      => false,
		'show_ui'           => true,
	) );
}